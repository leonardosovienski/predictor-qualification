"""Tratamento CoDa (compositional data) de razões contábeis — para a futura
família de distress contábil.

O problema (documentado no projeto de replicação de Altman que serviu de
referência): razões contábeis (ativo, passivo, lucro...) vivem no simplex —
somam a um total — e bases de demonstrativos brasileiros têm MUITOS zeros
(linha não reportada != zero econômico). As opções ruins usuais: descartar a
empresa (com N~30, cada linha perdida é poder estatístico jogado fora) ou
imputar zero (fabrica distress artificial — um zero de "lucro retido" não
reportado não é prejuízo acumulado).

A rota CoDa:
1. `impute_zeros`: substitui zeros pela metade do menor valor positivo da
   COLUNA (detection limit multiplicativo simples) — registrado, nunca
   silencioso: retorna também a máscara do que foi imputado.
2. `clr`: log-razão centrada — leva as razões do simplex para espaço real
   onde médias, distâncias e testes fazem sentido (média aritmética de
   razões no simplex é geometricamente errada).

Uso: distress contábil comparável ENTRE empresas sem jogar fora as que têm
dado parcial. Não alimenta as 8 famílias pré-registradas — só as next-gen.
"""
import math


def impute_zeros(matrix: list[list[float]], delta: float = 0.5) -> dict:
    """Substitui zeros/None por delta * (menor positivo da coluna).

    Retorna {"data": matriz imputada, "mask": posições imputadas,
    "dropped_cols": colunas sem nenhum positivo (não imputáveis — ficam como
    estão e o chamador decide)}. A máscara é parte do resultado: qualquer
    análise downstream deve poder auditar quanto do dado é imputado."""
    if not matrix:
        return {"data": [], "mask": [], "dropped_cols": []}
    n_cols = len(matrix[0])
    if any(len(row) != n_cols for row in matrix):
        raise ValueError(
            "matriz não retangular: linhas com tamanhos diferentes "
            f"(esperado {n_cols} colunas) — erro de domínio, não de CoDa")
    mins = []
    for c in range(n_cols):
        positives = [row[c] for row in matrix
                     if row[c] is not None and row[c] > 0]
        mins.append(min(positives) if positives else None)
    data, mask = [], []
    for r, row in enumerate(matrix):
        new_row = list(row)
        for c in range(n_cols):
            if (row[c] is None or row[c] == 0) and mins[c] is not None:
                new_row[c] = delta * mins[c]
                mask.append((r, c))
        data.append(new_row)
    dropped = [c for c in range(n_cols) if mins[c] is None]
    return {"data": data, "mask": mask, "dropped_cols": dropped}


def clr(row: list[float]) -> list[float] | None:
    """Centered log-ratio: ln(x_i / média geométrica(x)). Exige tudo > 0
    (rodar impute_zeros antes). Retorna None se algum valor for <= 0 —
    fail-closed, nunca log de zero silencioso."""
    if not row or any(x is None or x <= 0 for x in row):
        return None
    log_mean = sum(math.log(x) for x in row) / len(row)
    return [math.log(x) - log_mean for x in row]


def clr_matrix(matrix: list[list[float]], delta: float = 0.5) -> dict:
    """Pipeline completo: imputa zeros (com máscara auditável) e aplica CLR
    linha a linha. Colunas em `dropped_cols` (sem nenhum valor positivo em
    toda a matriz) são EXCLUÍDAS antes do CLR — do contrário elas carregam
    zero em toda linha e o `clr` fail-closed colapsa a matriz inteira para
    None (bug corrigido: uma única coluna sem dado inutilizava a análise
    toda). Linhas que continuam inválidas após a exclusão (ex.: outro valor
    <=0 fora de dropped_cols) viram None e são contadas."""
    imp = impute_zeros(matrix, delta=delta)
    dropped = set(imp["dropped_cols"])
    kept_cols = [c for c in range(len(matrix[0]) if matrix else 0) if c not in dropped]
    out, failed = [], 0
    for row in imp["data"]:
        trimmed = [row[c] for c in kept_cols]
        v = clr(trimmed)
        if v is None:
            failed += 1
        out.append(v)
    # `imp["mask"]` indexa colunas na numeração ORIGINAL (impute_zeros nunca
    # remove coluna); `out` acima já teve `dropped_cols` excluídas, então as
    # posições da máscara têm que ser remapeadas pra numeração NOVA — sem
    # isso, qualquer auditoria downstream usando `mask` contra `data` lê a
    # célula errada (ou estoura índice) sempre que dropped_cols não é vazio
    # (achado de varredura 2026-09-04). Colunas descartadas nunca aparecem em
    # `mask` (impute_zeros só marca imputação em colunas com `mins[c]` válido,
    # que são exatamente as mantidas), então o remapeamento é total.
    col_remap = {old: new for new, old in enumerate(kept_cols)}
    remapped_mask = [(r, col_remap[c]) for r, c in imp["mask"]]
    return {"data": out, "mask": remapped_mask, "dropped_cols": imp["dropped_cols"],
            "rows_failed": failed}
