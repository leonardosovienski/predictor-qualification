"""M5 — Walk-forward + pedágio de 2 lentes (PSR + bootstrap pareado) + veredito.

Encadeia M2-M4 numa passada forward mensal: a cada rebalance, universo point-in-time →
sinal momentum 12-1 → carteira quintil → segura até o próximo mês. Produz a curva DIÁRIA
de retornos da estratégia E do benchmark (equiponderado do universo), pareadas no tempo
— para o bloco-21-PREGÕES da H1 fazer sentido (periodicidade diária).

Veredito pelo PEDÁGIO canônico:
- Lente 1 (PSR): P(Sharpe da estratégia > Sharpe do benchmark), corrige não-normalidade.
- Lente 2 (block bootstrap PAREADO): IC da diferença de Sharpe; reamostra os pares
  (estratégia, benchmark) JUNTOS — preserva a cross-correlação. H1 COMPROVADA só se o
  IC 95% não cruzar zero.

Simplificações desta passada (registradas): retorno por preço ajustado de fechamento
(custo de turnover no rebalance); a robustez de execução a 3 preços (abertura/fechamento
D+1 / pior dos dois) e o purge/embargo formal ficam para a evolução do M5.
"""
import math
import statistics
import sys

if __package__:
    from . import adjust, db, execution, factor, portfolio, universe
    from .config import load_config
    from .execution import equal_weight_turnover_cost
    from .returns import month_end_dates
else:
    import adjust
    import db
    import execution
    import factor
    import portfolio
    from config import load_config
    from execution import equal_weight_turnover_cost
    from returns import month_end_dates
    import universe
from predictor_core.measurement.bootstrap import bootstrap_ci
from predictor_core.measurement.stats import (max_drawdown,
                                              probabilistic_sharpe_ratio, sharpe)

# equal_weight_turnover_cost agora vive em execution.py (canônica, ao lado da versão
# bruta calculate_turnover_cost — achado de revisão de código 2026-08-28: a duplicata
# local aqui arriscava divergir da correção já diagnosticada). Import acima mantém
# `backtest.equal_weight_turnover_cost` funcionando para quem já chamava por aqui.


def _daily_returns(dates, closes):
    return {dates[i]: closes[i] / closes[i - 1] - 1.0
            for i in range(1, len(closes)) if closes[i - 1] > 0}


def legacy_walk_forward(conn, cfg, signal_fn=None, take="top", portfolio_fn=None, series_fn=None):
    """Retorna (strat_diaria, bench_diaria) — listas pareadas de retornos diários.

    Custo de transação: proporcional ao turnover REAL entre rebalanceamentos
    consecutivos — papel que permanece na carteira não opera, logo não paga.
    cost_period = (n_saindo + n_entrando) × one_way / n_portfolio. Cobrar o
    roundtrip da carteira INTEIRA todo mês (modelo anterior) assumia turnover de
    100% e superestimava o arrasto contra a estratégia (auditoria Red Team 06/2026).

    `signal_fn(sub, asof) -> {ticker: sinal}` e `take` ("top"/"bottom") permitem
    plugar outra hipótese (H2: vol realizada, quintil inferior) na MESMA
    maquinaria de universo/custos/pareamento. Defaults = H1 exata.

    `portfolio_fn(sub, asof) -> {ticker: peso}` (H4+) troca a CONSTRUÇÃO por
    uma carteira PONDERADA (Σw=1): retorno diário = média ponderada dos pesos
    FIXOS do rebalance (denominador Σw permanece ~1 mesmo se algum ticker não
    tiver pregão no dia) e custo = turnover de pesos (Σ|Δw| × lado). Quando
    presente, ignora signal_fn/take. O caminho equiponderado de H1/H2
    permanece intocado.

    Convenção deliberada (achado de auditoria 2026-08-30, docstring corrigida
    para bater com o código, não o contrário): ticker sem retorno no dia
    (suspensão/iliquidez) entra como retorno 0 SEM sair do denominador — a
    mesma disciplina anti-viés-de-sobrevivência do ramo equiponderado acima
    (ver comentário em `srets`). Renormalizar só pelos "presentes no dia"
    daria peso extra grátis para quem sobreviveu, reintroduzindo exatamente o
    viés que essa disciplina existe para evitar.

    `series_fn(conn, ticker) -> (dates, closes)` (H11+, 2026-09-04): troca a
    FONTE de preço — default `adjust.adjusted_series` (rota (b), só-preço,
    H1-H10 intocadas byte a byte). `adjust.total_return_series` (rota (a),
    proventos reinvestidos) é o outro valor válido hoje.

    `cfg["backtest"]["test_end"]` (H11+, 2026-09-04): corta `rebal` numa
    data final — `None` (default) preserva o comportamento de H1-H10 (usa
    todo o histórico disponível). Necessário para hipóteses cuja fonte de
    dado (proventos, hoje) só tem cobertura confiável numa sub-janela.
    """
    adjust.require_scanned(conn)
    f, u = cfg["factor"], cfg["universe"]
    e, bt = cfg["execution"], cfg["backtest"]
    lookback_mom, skip = f.get("lookback_days", 252), f.get("skip_days", 21)
    if signal_fn is None:
        signal_fn = lambda sub, asof: factor.signals(sub, asof, lookback_mom, skip)
    top_n = u.get("top_n", 60)
    liq_lb, min_hist = u.get("lookback_trading_days", 126), u.get("min_history_days", 252)
    quant = 0.2  # top_quintile
    one_way = execution.one_way_cost(
        e.get("b3_fee_pct", 0.0003), e.get("spread_slippage_pct", 0.0015))
    test_start = bt.get("test_start", "0000-00-00")
    test_end = bt.get("test_end")   # None = sem corte (H1-H10, comportamento intocado)
    series_fn = series_fn or adjust.adjusted_series   # default = rota (b), H1-H10 intocadas

    # carga PREGUIÇOSA e memoizada: só tickers que entram em algum universo mensal —
    # o banco tem centenas de papéis (deslistados, curtos, quarentenados) que nunca
    # ranqueiam no top-N e cuja série nunca seria lida.
    series, dret = {}, {}

    def _load(tk):
        if tk not in series:
            dates, closes = series_fn(conn, tk)
            series[tk] = (dates, closes)
            dret[tk] = _daily_returns(dates, closes)

    all_dates = [r[0] for r in conn.execute(
        "SELECT DISTINCT date FROM prices_raw WHERE market_type = ? ORDER BY date",
        (universe.SPOT_MARKET,))]
    rebal = [d for d in month_end_dates(all_dates) if d >= test_start]
    if test_end is not None:
        rebal = [d for d in rebal if d <= test_end]

    strat, bench = [], []
    prev_port: set = set()
    prev_w: dict = {}
    for t, t1 in zip(rebal, rebal[1:]):
        uni = universe.legacy_select_universe(conn, t, top_n=top_n, lookback=liq_lb, min_history=min_hist)
        if not uni:
            continue
        for tk in uni:
            _load(tk)
        sub = {tk: series[tk] for tk in uni}
        if portfolio_fn is None:
            port = list(portfolio.select_portfolio(signal_fn(sub, t), quant, take=take))
            if not port:
                prev_port = set()
                continue
            port_set = set(port)
            # custo do turnover real: saídas pesam 1/len(prev_port), entradas
            # 1/len(port_set) — ver equal_weight_turnover_cost.
            period_cost = equal_weight_turnover_cost(prev_port, port_set, one_way)
            prev_port = port_set
            weights = None
        else:
            weights = portfolio_fn(sub, t)
            if not weights:
                prev_w = {}
                continue
            period_cost = execution.weighted_turnover_cost(prev_w, weights, one_way)
            prev_w = weights

        period = [d for d in all_dates if t < d <= t1]
        cost_pending = True   # cobra no 1º par de retornos REGISTRADO, não em j==0
        # (bug corrigido: se o 1º pregão do período não tiver retorno válido,
        # `continue` pulava o índice sem cobrar, e o `j` nunca mais voltava a
        # 0 — o custo do rebalance inteiro sumia do período, inflando o
        # retorno líquido).
        for d in period:
            brets = [dret[tk][d] for tk in uni if d in dret[tk]]
            if weights is None:
                # ativo sem retorno no dia (suspensão/iliquidez) NÃO é
                # descartado da média silenciosamente — entraria como peso
                # extra grátis para os sobreviventes (viés de sobrevivência).
                # Convenção declarada: retorno 0 no dia sem cotação, mantendo
                # o denominador em len(port) inteiro.
                srets = [dret[tk].get(d, 0.0) for tk in port]
                if not brets:
                    continue
                s = sum(srets) / len(port) - (period_cost if cost_pending else 0.0)
            else:
                # mesma convenção do ramo equiponderado acima: ticker sem retorno no
                # dia entra como 0, sem sair do denominador (anti-viés-de-sobrevivência
                # — ver docstring de `legacy_walk_forward`).
                sw = [(w, dret[tk].get(d, 0.0)) for tk, w in weights.items()]
                den = sum(w for w, _ in sw)
                if not brets or den <= 0:
                    continue
                s = sum(w * r for w, r in sw) / den - (period_cost if cost_pending else 0.0)
            cost_pending = False
            strat.append(s)
            bench.append(sum(brets) / len(brets))
    return strat, bench


def judge(strat, bench, cfg):
    """Pedágio de 2 lentes sobre as séries pareadas. Veredito da H1."""
    b = cfg.get("bootstrap", {})
    n_boot, block = b.get("n_boot", 10_000), b.get("block_length", 21)
    conf, seed = b.get("confidence", 0.95), b.get("seed", 42)
    scheme = b.get("method", "stationary")   # H1 pré-registra STATIONARY (bloco 21)
    if not strat:
        # série VAZIA não é "amostra curta" — é ausência de dados (o pipeline não
        # produziu nenhum par). Não pode se disfarçar de veredito estatístico.
        return {"n": 0, "psr": None, "sharpe_diff_ci": (None, None),
                "veredito": "SEM DADOS (pipeline vazio — histórico insuficiente)"}
    if len(strat) < 2 * block:
        return {"n": len(strat), "psr": None, "sharpe_diff_ci": (None, None),
                "veredito": "INCONCLUSIVO (amostra curta)"}

    def per_period(xs):
        sd = statistics.pstdev(xs) if len(xs) > 1 else 0.0
        return statistics.mean(xs) / sd if sd else 0.0

    psr = probabilistic_sharpe_ratio(strat, benchmark_sharpe=per_period(bench))

    def diff_sharpe(window):
        d = sharpe([x[0] for x in window], 252) - sharpe([x[1] for x in window], 252)
        # Core discards both None and nonfinite statistics. Match its float
        # contract without changing which resamples enter the historical CI.
        return d if math.isfinite(d) else float('nan')

    lo, hi, _ = bootstrap_ci(list(zip(strat, bench)), diff_sharpe, scheme=scheme,
                             block_length=block, n_boot=n_boot, confidence=conf, seed=seed)
    comprovada = lo is not None and lo > 0
    return {"n": len(strat), "psr": psr, "sharpe_diff_ci": (lo, hi),
            "veredito": "COMPROVADA" if comprovada else "não comprovada (IC cruza 0 / negativo)"}


def run(cfg=None, conn=None, write_report=False, run_id=None):
    cfg = cfg or load_config()
    conn = conn or db.get_connection()
    strat, bench = legacy_walk_forward(conn, cfg)
    verdict = judge(strat, bench, cfg)
    print(f"walk-forward: {verdict['n']} pregões | PSR={verdict['psr']} | "
          f"IC95% diff-Sharpe={verdict['sharpe_diff_ci']} | H1: {verdict['veredito']}")
    if write_report:
        import report
        path = report.write_report(verdict, strat, bench, cfg, run_id=run_id)
        print(f"relatório: {path}")
    return verdict


def _conclude(verdict, strat, bench, cfg, hypothesis, write_report, run_id, extra=""):
    """Fecho comum das hipóteses H2+: imprime a linha do veredito (com DSR) e,
    se pedido, grava o relatório rotulado. Retorna o verdict inalterado."""
    import economics
    print(f"walk-forward {hypothesis}: {verdict['n']} pregões | PSR={verdict['psr']} | "
          f"IC95% diff-Sharpe={verdict['sharpe_diff_ci']} | "
          f"DSR={verdict.get('dsr')} (N={verdict.get('n_trials')}, "
          f"desconto aplicado={verdict.get('deflation_applied')}) | "
          f"{extra}{hypothesis}: {verdict['veredito']}")
    # Screen econômico READ-ONLY: não participa do veredito, roda depois dele.
    # Existe porque um NOT_SUPPORTED e um "real mas pequeno demais" levam a
    # decisões diferentes, e até 2026-09-07 o domínio não distinguia os dois.
    print(economics.summary_line(strat, cfg))
    if write_report:
        import report
        path = report.write_report(verdict, strat, bench, cfg, run_id=run_id,
                                   hypothesis=hypothesis)
        print(f"relatório: {path}")
    return verdict


def _max_dd(returns):
    """Max drawdown da curva de capital (base 1.0) de uma série de retornos."""
    eq, v = [], 1.0
    for r in returns:
        v *= 1.0 + r
        eq.append(v)
    return max_drawdown(eq)


def _h4_extra_criteria(strat, bench, cfg):
    """Critério (iii) da H4 ("julgado por Sharpe líquido E drawdown", design §10):
    maxDD da estratégia <= maxDD do benchmark. Isolado do runner genérico porque só
    a H4 tem um 3º critério além de IC+DSR."""
    dd_s = dd_b = None
    failures = []
    if strat and cfg.get("h4_criteria", {}).get("require_maxdd_not_worse", True):
        dd_s, dd_b = _max_dd(strat), _max_dd(bench)
        if dd_s > dd_b:
            failures.append(f"maxDD estratégia {dd_s:.2%} > benchmark {dd_b:.2%}")
    return failures, {"maxdd_strat": dd_s, "maxdd_bench": dd_b}, f"maxDD strat/bench={dd_s}/{dd_b} | "


def _run_hypothesis(hypothesis, trial_name, frozen_keys, criteria_section, notes,
                    cfg, conn, write_report, run_id, trials_path,
                    signal_fn=None, take="top", portfolio_fn=None,
                    extra_criteria=None, series_fn=None):
    """Runner comum das hipóteses H2+ (achado de revisão de código 2026-08-28: os
    run_hN eram 5 funções quase idênticas copiadas à mão — a mesma duplicação que já
    causou o bug real do clobber de sharpe da H2, ver `trials_gate.register_hypothesis`).
    Cada `run_hN` abaixo fica só com o que É específico dela: extrair os parâmetros
    `[hN-FROZEN]` do config e montar `signal_fn`/`take`/`portfolio_fn`.

    `series_fn` (H11+, 2026-09-04): repassado para `legacy_walk_forward` — troca a
    fonte de preço (default `adjust.adjusted_series`, rota (b))."""
    strat, bench = legacy_walk_forward(conn, cfg, signal_fn=signal_fn, take=take,
                                portfolio_fn=portfolio_fn, series_fn=series_fn)
    return _finalize_hypothesis(hypothesis, trial_name, frozen_keys, criteria_section,
                                notes, cfg, write_report, run_id, trials_path,
                                strat, bench, extra_criteria=extra_criteria)


def _finalize_hypothesis(hypothesis, trial_name, frozen_keys, criteria_section, notes,
                         cfg, write_report, run_id, trials_path, strat, bench,
                         extra_criteria=None):
    """Fecho comum: pedágio (judge+DSR) + registro + relatório, dado
    `strat`/`bench` JÁ calculados. Extraído de `_run_hypothesis` (H16,
    2026-09-04) — H16 não usa `legacy_walk_forward` (mecânica de TIMING, não
    seleção mensal por fator), mas usa o MESMO pedágio/registro de todas
    as anteriores; nenhuma delas foi alterada por este refactor."""
    import trials_gate
    base = judge(strat, bench, cfg)
    extra_failures, extra_fields, extra_text = [], {}, ""
    if extra_criteria is not None:
        extra_failures, extra_fields, extra_text = extra_criteria(strat, bench, cfg)
    verdict = trials_gate.apply_dsr(
        base, strat, cfg, trials_path=trials_path,
        trial_name=trial_name, frozen_keys=frozen_keys,
        criteria_section=criteria_section, extra_failures=extra_failures, notes=notes)
    verdict.update(extra_fields)
    return _conclude(verdict, strat, bench, cfg, hypothesis, write_report, run_id,
                     extra=extra_text)


def run_h2(cfg=None, conn=None, write_report=False, run_id=None, trials_path=None):
    """H2 — baixa volatilidade (pré-registro 2026-07-16). MESMA maquinaria da H1
    (universo/custos/pareamento/pedágio); o que muda é o sinal (vol realizada,
    quintil INFERIOR) e o critério extra da 2ª hipótese: DSR >= dsr_min,
    descontado por todas as tentativas do trials.json (trials_gate)."""
    cfg = cfg or load_config()
    conn = conn or db.get_connection()
    lb = cfg.get("h2_factor", {}).get("lookback_days", 252)
    return _run_hypothesis(
        "H2", "h2-lowvol-252", None, "h2_criteria", None,
        cfg, conn, write_report, run_id, trials_path,
        signal_fn=lambda sub, asof: factor.vol_signals(sub, asof, lb), take="bottom")


def run_h4(cfg=None, conn=None, write_report=False, run_id=None, trials_path=None):
    """H4 — sizing por volatility targeting (pré-registro 2026-07-18): universo
    INTEIRO com peso ∝ 1/vol realizada 252d vs. o MESMO universo equiponderado.
    Critérios (todos, fixados a priori): (i) IC95% diff-Sharpe > 0;
    (ii) DSR >= dsr_min (N=3 tentativas); (iii) maxDD da estratégia <= maxDD do
    benchmark ("julgado por Sharpe líquido E drawdown", design §10)."""
    from config import H4_FROZEN_KEYS
    cfg = cfg or load_config()
    conn = conn or db.get_connection()
    lb = cfg.get("h4_weighting", {}).get("vol_lookback_days", 252)
    return _run_hypothesis(
        "H4", "h4-invvol-sizing-252", H4_FROZEN_KEYS, "h4_criteria",
        "rodada única da H4 (sizing 1/vol; sharpe por-período realizado)",
        cfg, conn, write_report, run_id, trials_path,
        portfolio_fn=lambda sub, asof: portfolio.inverse_vol_weights(
            factor.vol_signals(sub, asof, lb)),
        extra_criteria=_h4_extra_criteria)


def run_h5(cfg=None, conn=None, write_report=False, run_id=None, trials_path=None):
    """H5 — reversão de curto prazo (pré-registro 2026-07-18): quintil INFERIOR
    do retorno de 21 pregões (perdedores do mês), mesma maquinaria de
    universo/custos/pedágio. Critérios: (i) IC95% diff-Sharpe > 0;
    (ii) DSR >= dsr_min (N=4 tentativas). O sinal é momentum_12_1 com
    lookback=21, skip=0 — retorno de [asof-21, asof] na série ajustada."""
    from config import H5_FROZEN_KEYS
    cfg = cfg or load_config()
    conn = conn or db.get_connection()
    h5f = cfg.get("h5_factor", {})
    lb, skip = h5f.get("lookback_days", 21), h5f.get("skip_days", 0)
    return _run_hypothesis(
        "H5", "h5-strev-21", H5_FROZEN_KEYS, "h5_criteria",
        "rodada única da H5 (reversão 21d; sharpe por-período realizado)",
        cfg, conn, write_report, run_id, trials_path,
        signal_fn=lambda sub, asof: factor.signals(sub, asof, lb, skip), take="bottom")


def run_h6(cfg=None, conn=None, write_report=False, run_id=None, trials_path=None):
    """H6 — momentum 6-1 (pré-registro 2026-08-27): MESMA maquinaria da H1,
    janela mais curta (126 pregões ~6 meses, skip 21) — hipótese de que a B3
    (menos líquida/eficiente que mercados desenvolvidos) incorpora momentum
    numa janela mais curta que o clássico 12-1 (que fracassou na H1)."""
    from config import H6_FROZEN_KEYS
    cfg = cfg or load_config()
    conn = conn or db.get_connection()
    h6f = cfg.get("h6_factor", {})
    lb, skip = h6f.get("lookback_days", 126), h6f.get("skip_days", 21)
    return _run_hypothesis(
        "H6", "h6-momentum-6-1", H6_FROZEN_KEYS, "h6_criteria",
        "rodada única da H6 (momentum 6-1; sharpe por-período realizado)",
        cfg, conn, write_report, run_id, trials_path,
        signal_fn=lambda sub, asof: factor.signals(sub, asof, lb, skip), take="top")


def run_h8(cfg=None, conn=None, write_report=False, run_id=None, trials_path=None):
    """H8 — filtro duplo momentum ∩ baixa vol (pré-registro 2026-08-27): top
    `h8_portfolio.momentum_quantile` do universo por momentum 12-1, depois a
    fração `h8_portfolio.vol_quantile` de menor vol realizada DENTRO desse
    subconjunto. H1 (momentum isolado) e H2 (baixa vol isolada) fracassaram —
    hipótese distinta: a interseção filtra o lado mais arriscado do momentum."""
    from config import H8_FROZEN_KEYS
    cfg = cfg or load_config()
    conn = conn or db.get_connection()
    h8f = cfg.get("h8_factor", {})
    mom_lb = h8f.get("momentum_lookback_days", 252)
    mom_skip = h8f.get("momentum_skip_days", 21)
    vol_lb = h8f.get("vol_lookback_days", 252)
    h8p = cfg.get("h8_portfolio", {})
    mom_q = h8p.get("momentum_quantile", 0.4)
    vol_q = h8p.get("vol_quantile", 0.5)

    def _pf(sub, asof):
        mom = factor.signals(sub, asof, mom_lb, mom_skip)
        vol = factor.vol_signals(sub, asof, vol_lb)
        return portfolio.momentum_lowvol_double_filter(mom, vol, mom_q, vol_q)

    return _run_hypothesis(
        "H8", "h8-mom-lowvol-double", H8_FROZEN_KEYS, "h8_criteria",
        "rodada única da H8 (filtro duplo momentum top ∩ baixa vol; "
        "sharpe por-período realizado)",
        cfg, conn, write_report, run_id, trials_path, portfolio_fn=_pf)


def run_h7(cfg=None, conn=None, write_report=False, run_id=None, trials_path=None):
    """H7 — fator de qualidade, ROE isolado (pré-registro 2026-09-03): quintil
    SUPERIOR de ROE (lucro líquido / patrimônio líquido, `fundamentals` da
    CVM/DFP), embargo de divulgação sobre `ref_date` (`factor.roe_signals`),
    mesma maquinaria de universo/custos/pareamento/pedágio das anteriores.
    1ª hipótese sobre dado contábil — todas as anteriores (H1/H2/H4/H5/H6/H8)
    são só-preço. Critérios: (i) IC95% diff-Sharpe > 0; (ii) DSR >= dsr_min
    (N=7 tentativas no registro)."""
    from config import H7_FROZEN_KEYS
    cfg = cfg or load_config()
    conn = conn or db.get_connection()
    h7f = cfg.get("h7_factor", {})
    embargo = h7f.get("disclosure_embargo_days", 90)
    return _run_hypothesis(
        "H7", "h7-quality-roe", H7_FROZEN_KEYS, "h7_criteria",
        "rodada única da H7 (ROE isolado, quintil superior; sharpe por-período realizado)",
        cfg, conn, write_report, run_id, trials_path,
        signal_fn=lambda sub, asof: factor.roe_signals(conn, sub.keys(), asof, embargo),
        take="top")


def run_h9(cfg=None, conn=None, write_report=False, run_id=None, trials_path=None):
    """H9 — fator de qualidade, alavancagem isolada (pré-registro 2026-09-04):
    quintil INFERIOR de alavancagem (`fundamentals.leverage`, empresas menos
    endividadas — mesmo racional de tilt de qualidade/baixo risco de H2/H4,
    aplicado a dado contábil), mesma fonte DFP/embargo da H7. Critérios:
    (i) IC95% diff-Sharpe > 0; (ii) DSR >= dsr_min (N=8 tentativas no
    registro)."""
    from config import H9_FROZEN_KEYS
    cfg = cfg or load_config()
    conn = conn or db.get_connection()
    h9f = cfg.get("h9_factor", {})
    embargo = h9f.get("disclosure_embargo_days", 90)
    return _run_hypothesis(
        "H9", "h9-quality-leverage", H9_FROZEN_KEYS, "h9_criteria",
        "rodada única da H9 (alavancagem isolada, quintil inferior; "
        "sharpe por-período realizado)",
        cfg, conn, write_report, run_id, trials_path,
        signal_fn=lambda sub, asof: factor.leverage_signals(conn, sub.keys(), asof, embargo),
        take="bottom")


def run_h10(cfg=None, conn=None, write_report=False, run_id=None, trials_path=None):
    """H10 — filtro duplo ROE ∩ baixa alavancagem (pré-registro 2026-09-04):
    top `h10_portfolio.roe_quantile` do universo por ROE, depois a fração
    `h10_portfolio.leverage_quantile` de menor alavancagem DENTRO desse
    subconjunto. H7 (ROE isolado) e H9 (alavancagem isolada) fracassaram —
    hipótese distinta: a interseção filtra o lado mais arriscado de cada
    fator isolado (mesmo racional da H8 sobre momentum/vol)."""
    from config import H10_FROZEN_KEYS
    cfg = cfg or load_config()
    conn = conn or db.get_connection()
    h10f = cfg.get("h10_factor", {})
    roe_embargo = h10f.get("roe_disclosure_embargo_days", 90)
    lev_embargo = h10f.get("leverage_disclosure_embargo_days", 90)
    h10p = cfg.get("h10_portfolio", {})
    roe_q = h10p.get("roe_quantile", 0.4)
    lev_q = h10p.get("leverage_quantile", 0.5)

    def _pf(sub, asof):
        roe = factor.roe_signals(conn, sub.keys(), asof, roe_embargo)
        lev = factor.leverage_signals(conn, sub.keys(), asof, lev_embargo)
        return portfolio.roe_lowlev_double_filter(roe, lev, roe_q, lev_q)

    return _run_hypothesis(
        "H10", "h10-roe-leverage-double", H10_FROZEN_KEYS, "h10_criteria",
        "rodada única da H10 (filtro duplo ROE top ∩ baixa alavancagem; "
        "sharpe por-período realizado)",
        cfg, conn, write_report, run_id, trials_path, portfolio_fn=_pf)


def run_h11(cfg=None, conn=None, write_report=False, run_id=None, trials_path=None):
    """H11 — momentum 12-1 em RETORNO TOTAL (pré-registro 2026-09-04): mesmo
    sinal da H1, mas sobre `adjust.total_return_series` (proventos
    reinvestidos) em vez de só-preço, testando se o viés declarado no
    pré-registro da H1 ("omitir proventos FAVORECE momentum") de fato
    inflava o resultado. Janela restrita a `h11_backtest.test_start/
    test_end` (2018-2022) — cobertura real de `dividends` (CVM/FRE) não
    alcança 2023-2026 (achado registrado no HANDOFF 2026-09-04)."""
    from config import H11_FROZEN_KEYS
    cfg = cfg or load_config()
    conn = conn or db.get_connection()
    h11f = cfg.get("h11_factor", {})
    lb, skip = h11f.get("lookback_days", 252), h11f.get("skip_days", 21)
    h11bt = cfg.get("h11_backtest", {})

    # cópia rasa de cfg["backtest"] só pra esta rodada — janela restrita da
    # H11 não deve vazar pro cfg compartilhado nem afetar H1-H10.
    run_cfg = dict(cfg)
    run_cfg["backtest"] = dict(cfg.get("backtest", {}))
    run_cfg["backtest"]["test_start"] = h11bt.get("test_start", "2018-01-01")
    run_cfg["backtest"]["test_end"] = h11bt.get("test_end")

    return _run_hypothesis(
        "H11", "h11-momentum-12-1-total-return", H11_FROZEN_KEYS, "h11_criteria",
        "rodada única da H11 (momentum 12-1, retorno total, janela 2018-2022; "
        "sharpe por-período realizado)",
        run_cfg, conn, write_report, run_id, trials_path,
        signal_fn=lambda sub, asof: factor.signals(sub, asof, lb, skip), take="top",
        series_fn=adjust.legacy_total_return_series)


def run_h12(cfg=None, conn=None, write_report=False, run_id=None, trials_path=None):
    """H12 — fator de qualidade, margem líquida isolada (pré-registro
    2026-09-04): quintil SUPERIOR de margem líquida (`fundamentals.net_margin`
    = lucro_liquido/receita_liquida, DFP/CVM), mesma fonte/embargo de
    H7/H9/H10 — sem ingestão nova (receita já vinha na DRE parseada desde a
    H7, só não era extraída). Racional: margem é qualidade OPERACIONAL,
    distinta de ROE (que mistura alavancagem financeira no numerador via
    identidade contábil) — H7 (ROE) e H9 (alavancagem) isoladas reprovaram;
    H12 testa a 3ª variável contábil independente disponível na DFP.
    Critérios: (i) IC95% diff-Sharpe > 0; (ii) DSR >= dsr_min (N=11
    tentativas no registro)."""
    from config import H12_FROZEN_KEYS
    cfg = cfg or load_config()
    conn = conn or db.get_connection()
    h12f = cfg.get("h12_factor", {})
    embargo = h12f.get("disclosure_embargo_days", 90)
    return _run_hypothesis(
        "H12", "h12-quality-net-margin", H12_FROZEN_KEYS, "h12_criteria",
        "rodada única da H12 (margem líquida isolada, quintil superior; "
        "sharpe por-período realizado)",
        cfg, conn, write_report, run_id, trials_path,
        signal_fn=lambda sub, asof: factor.net_margin_signals(conn, sub.keys(), asof, embargo),
        take="top")


def run_h13(cfg=None, conn=None, write_report=False, run_id=None, trials_path=None):
    """H13 — crescimento de receita YoY (pré-registro 2026-09-04): quintil
    SUPERIOR de crescimento de receita líquida ano-contra-ano
    (`factor.revenue_growth_signals`, DFP/CVM), mesma fonte/embargo de
    H7/H9/H10/H12. Primeira hipótese de CRESCIMENTO testada neste domínio —
    todas as 11 anteriores são nível/valor (momentum é o mais próximo, mas
    mede preço, não fundamento). Racional: literatura de "growth investing"
    associa aceleração de receita a retorno futuro, mecanismo distinto de
    qualidade/valor. Critérios: (i) IC95% diff-Sharpe > 0; (ii) DSR >=
    dsr_min (N=12 tentativas no registro)."""
    from config import H13_FROZEN_KEYS
    cfg = cfg or load_config()
    conn = conn or db.get_connection()
    h13f = cfg.get("h13_factor", {})
    embargo = h13f.get("disclosure_embargo_days", 90)
    return _run_hypothesis(
        "H13", "h13-revenue-growth-yoy", H13_FROZEN_KEYS, "h13_criteria",
        "rodada única da H13 (crescimento de receita YoY, quintil superior; "
        "sharpe por-período realizado)",
        cfg, conn, write_report, run_id, trials_path,
        signal_fn=lambda sub, asof: factor.revenue_growth_signals(conn, sub.keys(), asof, embargo),
        take="top")


def run_h14(cfg=None, conn=None, write_report=False, run_id=None, trials_path=None):
    """H14 — proximidade da máxima de 52 semanas (pré-registro 2026-09-04):
    quintil SUPERIOR de `close(asof)/max(close, 252 pregões)`
    (`factor.near_52w_high_signals`). Fator de preço distinto de momentum
    (George & Hwang 2004) — mesma maquinaria de universo/custos/pareamento/
    pedágio de H1, zero dado novo (só preço já ajustado). Critérios: (i)
    IC95% diff-Sharpe > 0; (ii) DSR >= dsr_min (N=13 tentativas no
    registro)."""
    from config import H14_FROZEN_KEYS
    cfg = cfg or load_config()
    conn = conn or db.get_connection()
    h14f = cfg.get("h14_factor", {})
    lookback = h14f.get("lookback_days", 252)
    return _run_hypothesis(
        "H14", "h14-near-52w-high", H14_FROZEN_KEYS, "h14_criteria",
        "rodada única da H14 (proximidade da máxima 52 semanas, quintil "
        "superior; sharpe por-período realizado)",
        cfg, conn, write_report, run_id, trials_path,
        signal_fn=lambda sub, asof: factor.near_52w_high_signals(sub, asof, lookback),
        take="top")


def run_h15(cfg=None, conn=None, write_report=False, run_id=None, trials_path=None):
    """H15 — volume anormal (pré-registro 2026-09-04): quintil SUPERIOR de
    `volume_médio_21d/volume_médio_252d − 1` (`factor.volume_surge_signals`)
    — `volume_fin` já vive em `prices_raw` desde o M1 (usado só pra
    ranquear liquidez do universo), nunca como sinal de seleção. Mesma
    maquinaria de universo/custos/pareamento/pedágio de H1, zero dado
    novo. Racional: surto de volume recente pode antecipar informação
    nova incorporada ao preço (literatura de volume-price, distinta de
    momentum/proximidade-de-máxima). Critérios: (i) IC95% diff-Sharpe > 0;
    (ii) DSR >= dsr_min (N=14 tentativas no registro)."""
    from config import H15_FROZEN_KEYS
    cfg = cfg or load_config()
    conn = conn or db.get_connection()
    h15f = cfg.get("h15_factor", {})
    short_lb = h15f.get("short_lookback_days", 21)
    long_lb = h15f.get("long_lookback_days", 252)
    return _run_hypothesis(
        "H15", "h15-volume-surge", H15_FROZEN_KEYS, "h15_criteria",
        "rodada única da H15 (volume anormal, quintil superior; "
        "sharpe por-período realizado)",
        cfg, conn, write_report, run_id, trials_path,
        signal_fn=lambda sub, asof: factor.volume_surge_signals(
            conn, sub.keys(), asof, short_lb, long_lb),
        take="top")


def run_h17(cfg=None, conn=None, write_report=False, run_id=None, trials_path=None):
    """Protected: corrected measurement needs a new preregistration before observation."""
    raise ValueError("H17 PAUSED: CVM/execution methodology changed; validate the rebuilt "
                     "dataset and preregister the corrected instrument before observing performance.")


def run_h18(cfg=None, conn=None, write_report=False, run_id=None, trials_path=None):
    """Protected: corrected measurement needs a new preregistration before observation."""
    raise ValueError("H18 PAUSED: CVM/execution methodology changed; validate the rebuilt "
                     "dataset and preregister the corrected instrument before observing performance.")


def run_h19(cfg=None, conn=None, write_report=False, run_id=None, trials_path=None):
    """Protected: corrected measurement needs a new preregistration before observation."""
    raise ValueError("H19 PAUSED: CVM/execution methodology changed; validate the rebuilt "
                     "dataset and preregister the corrected instrument before observing performance.")


def _turn_of_month_days(dates, last_days=1, first_days=3):
    """{pregões dentro da janela virada-de-mês} — últimos `last_days`
    pregões do mês corrente + primeiros `first_days` pregões do mês
    seguinte (Lakonishok & Smidt 1988, "turn-of-the-month effect").
    `dates` ordenado asc, agrupado por `YYYY-MM`."""
    by_month = {}
    for d in dates:
        by_month.setdefault(d[:7], []).append(d)
    months = sorted(by_month)
    tom = set()
    for i, m in enumerate(months):
        tom.update(by_month[m][-last_days:])
        if i + 1 < len(months):
            tom.update(by_month[months[i + 1]][:first_days])
    return tom


def run_h16(cfg=None, conn=None, write_report=False, run_id=None, trials_path=None):
    """H16 — efeito virada-de-mês (pré-registro 2026-09-04): retorno
    anormal nos pregões ao redor da virada de mês (Lakonishok & Smidt
    1988) — últimos `last_days_of_month` pregões do mês + primeiros
    `first_days_of_month` do mês seguinte. PRIMEIRA hipótese de TIMING
    testada neste domínio — H1-H15 são todas seleção transversal (QUAIS
    papéis escolher); H16 testa QUANDO estar posicionado, no MESMO
    universo (não seleciona por fator nenhum).

    Mecânica NOVA, não reusa `legacy_walk_forward` (que é seleção mensal por
    fator) — universo rebalanceado mensalmente (mesma disciplina PIT de
    `universe.select_universe`), carteira equiponderada FIXA entre
    rebalances (mesma de H1). A estratégia só "conta" o retorno do dia
    (posicionada) nos pregões de virada-de-mês; o BENCHMARK é a MESMA
    carteira posicionada TODO dia — isola o efeito de TIMING do efeito de
    qual universo foi escolhido (os dois usam exatamente o mesmo top_n por
    liquidez). Custo: um `one_way` na transição cash→posicionado E
    posicionado→cash (aproximação declarada: ignora turnover de composição
    do universo entre rebalances mensais — o custo dominante aqui é a
    entrada/saída do timing, não a rotação de membros).

    Usa o MESMO pedágio/registro de todas as anteriores via
    `_finalize_hypothesis` (extraído de `_run_hypothesis` nesta mesma
    sessão — H1-H15 continuam usando `legacy_walk_forward`, comportamento
    intocado). Critérios: (i) IC95% diff-Sharpe > 0; (ii) DSR >= dsr_min
    (N=15 tentativas no registro)."""
    from config import H16_FROZEN_KEYS
    import returns as returns_mod
    cfg = cfg or load_config()
    conn = conn or db.get_connection()
    adjust.require_scanned(conn)
    u, e, bt = cfg["universe"], cfg["execution"], cfg["backtest"]
    h16f = cfg.get("h16_factor", {})
    last_days = h16f.get("last_days_of_month", 1)
    first_days = h16f.get("first_days_of_month", 3)
    top_n = u.get("top_n", 60)
    liq_lb, min_hist = u.get("lookback_trading_days", 126), u.get("min_history_days", 252)
    test_start = bt.get("test_start", "0000-00-00")
    one_way = execution.one_way_cost(
        e.get("b3_fee_pct", 0.0003), e.get("spread_slippage_pct", 0.0015))

    all_dates = [r[0] for r in conn.execute(
        "SELECT DISTINCT date FROM prices_raw WHERE market_type=? AND date>=?"
        " ORDER BY date", (universe.SPOT_MARKET, test_start))]
    if not all_dates:
        raise ValueError("H16: nenhum pregão >= backtest.test_start")
    tom_days = _turn_of_month_days(all_dates, last_days, first_days)
    month_ends = returns_mod.month_end_dates(all_dates)

    series, dret = {}, {}

    def _load(tk):
        if tk not in series:
            dates, closes = adjust.adjusted_series(conn, tk)
            series[tk] = (dates, closes)
            d = {dates[i]: closes[i] / closes[i - 1] - 1.0
                for i in range(1, len(dates)) if closes[i - 1] > 0}
            dret[tk] = d
        return dret[tk]

    strat, bench = [], []
    current, next_rebal_idx, prev_in_window = None, 0, False
    for day in all_dates:
        # rebalanceia no primeiro pregão >= cada fim-de-mês elegível (PIT:
        # asof = fim-de-mês, universo só vê dado < asof).
        while next_rebal_idx < len(month_ends) and month_ends[next_rebal_idx] <= day:
            asof = month_ends[next_rebal_idx]
            current = universe.legacy_select_universe(conn, asof, top_n, liq_lb, min_hist)
            next_rebal_idx += 1
        if not current:
            continue
        rets = [_load(tk).get(day, 0.0) for tk in current]
        bench_ret = sum(rets) / len(rets) if rets else 0.0
        in_window = day in tom_days
        strat_ret = bench_ret if in_window else 0.0
        if in_window != prev_in_window:
            strat_ret -= one_way   # entra/sai do timing: paga 1 perna
        prev_in_window = in_window
        strat.append(strat_ret)
        bench.append(bench_ret)

    return _finalize_hypothesis(
        "H16", "h16-turn-of-month", H16_FROZEN_KEYS, "h16_criteria",
        "rodada única da H16 (efeito virada-de-mês; sharpe por-período realizado)",
        cfg, write_report, run_id, trials_path, strat, bench)


if __name__ == "__main__":
    if run() is None:
        sys.exit(1)



def walk_forward(conn, cfg, signal_fn=None, take="top", portfolio_fn=None, series_fn=None):
    """Corrected instrument. Historical hypothesis runners explicitly use legacy_walk_forward."""
    if __package__:
        from .simulation import walk_forward as simulate
    else:
        from simulation import walk_forward as simulate
    return simulate(conn, cfg, signal_fn, take, portfolio_fn, series_fn)
